import { Routes, Route } from 'react-router-dom';
import './App.css';
import Navbar from './Navbar';
import Home from './pages/home';
import About from './pages/about';
import Contact from './pages/contact';
import Projects from './pages/project';

function App() {
  return (
    <>
    <h1>Welcome to My Portfolio</h1>
 
      <Navbar />
      <div className="main-content">
        <Routes>
          <Route path="/" element={<p>Main Page</p>} />
          <Route path="/home" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="*" element={<p>404 - Page not found</p>} />
        </Routes>
      </div>
      </>

  );
}

export default App;
