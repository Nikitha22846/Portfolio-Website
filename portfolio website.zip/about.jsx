import React from 'react';

function About() {
  return(
    <>
     <h2>About Us</h2>
    <p>I specialize in HTML, CSS, JavaScript, and React — and I love turning design ideas into real-world user experiences.</p>
  <p>My approach is focused on clean code, smooth animations, and a mobile-first mindset.</p>
  <p>Outside of work, I enjoy hiking, photography, and learning new tools in the tech space.</p>
  <a href="c:\Users\Sweety\OneDrive\ドキュメント\Nikitha Resume.pdf" download>Download Resume</a></>
  );

}

export default About;
