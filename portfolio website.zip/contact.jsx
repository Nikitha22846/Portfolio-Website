import React from 'react';

function Contact() {
  return(
    <>
    <h2>Contact Page</h2>
    <div className="contact-info">
    Name: Gunrati Nikitha<br></br>
    Email: gunratinikitha05@gmail.com<br></br>
    Phone: 9703573598<br></br>
    Address: Hyderabad<br></br>
    GitHub: https://github.com/gunratinikitha<br></br>
    linkedin: https://www.linkedin.com/in/gunrati-nikitha-3a9b5a258
    </div>
    
  
  
    </>
  );
}

export default Contact;
