import React from 'react';

function Home() {
  return (
    <>
     <h2>Hi, I'm Gunrati Nikitha</h2>
    <img className='img' src="https://as1.ftcdn.net/jpg/01/61/93/04/1000_F_161930461_pVfghvvClluNeHFmWa0sinFnhBopTsL9.jpg" alt="img" width="200px" height="200px"></img>
  
 
  <p>Web Developer & Designer</p>
  <p>I create beautiful and fast websites that help businesses grow online.</p>

  </>
  );
  
}

export default Home;
