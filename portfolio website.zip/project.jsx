import React from 'react';

function Projects() {
  return (
    <>
  <h2>Our Projects</h2>

  
  
    <h3>Grammar Genius with AI</h3>
    <p>
      This project showcases my work on a user-friendly interface built with modern HTML, CSS, and JavaScript. 
      The goal was to design a clean layout that highlights user interaction and performance.
    </p>
    <p>
      Features include responsive design, smooth transitions, and optimized image handling. 
      I used tools like Figma for UI planning and React for implementation.
      It can check the grammar of a sentence and provide suggestions for improvements.
      It give accurate efficiency.
    </p>
  

  

    

  </>
  );
}

export default Projects;
